<!doctype html>
<html lang='id'>
<head>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <meta name='csrf-token' content='<?= csrf_hash() ?>'>
  <title>AIWalas</title>
  <link rel='stylesheet' href='<?= base_url('assets/styles.css?v=20260920-teacher-action-grid') ?>'>
</head>
<style>
.assessment-table .score-name small{display:block;font-size:10px;font-weight:400;color:var(--muted);line-height:1.25;margin-top:2px}
.teacher-journal-table{width:100%;min-width:760px;table-layout:fixed}.teacher-journal-table .journal-date-col{width:145px}.teacher-journal-table .journal-wide-col{width:34%}.teacher-journal-table .journal-author-col{width:150px}.teacher-journal-table textarea{width:100%;min-height:58px;resize:vertical;box-sizing:border-box;padding:8px;border:1px solid var(--line);border-radius:6px;font:inherit;font-size:11px;line-height:1.4}.teacher-journal-table input,.teacher-journal-table select{width:100%;box-sizing:border-box;padding:9px 7px;border:1px solid var(--line);border-radius:6px;font:inherit;font-size:11px}
</style>
<style>.teacher-journal-wrap + .assessment-save-row{justify-content:space-between;text-align:left}.teacher-journal-wrap + .assessment-save-row .stat-note{text-align:left;flex:1;position:relative;left:5mm;top:3mm;transform:translateX(10mm)}.teacher-journal-wrap + .assessment-save-row #saveJournal{margin-left:auto;display:block;transform:translate(-5mm,-5mm)}</style>
<body>
<?= $this->renderSection('content') ?>
<script src='<?= base_url('assets/student-details.js?v=20260911') ?>'></script>
<script src='<?= base_url('assets/app.js?v=20260916-schedule-form-title') ?>'></script>
<script src='<?= base_url('assets/teacher-role.js?v=20260920-assessment-journal') ?>'></script>
<script src='<?= base_url('assets/whatsapp-notifications.js?v=20260918-communication-compose') ?>'></script>
<script src='<?= base_url('assets/students-page.js?v=20260918-import-excel') ?>'></script>
<script src='<?= base_url('assets/school-teachers.js?v=20260913-teachers-export6') ?>'></script>
<script src='<?= base_url('assets/school-teachers-mapel.js?v=20260918-mapel-kelas-imported') ?>'></script>
<script src='<?= base_url('assets/school-teachers-actions.js?v=20260919-detail-trash') ?>'></script>
<script src='<?= base_url('assets/school-teachers-cleanup.js?v=20260919') ?>'></script>
<script src='<?= base_url('assets/school-teachers-layout.js?v=20260920') ?>'></script>
<script src='<?= base_url('assets/api-ui.js?v=20260913-journal') ?>'></script>
<script src='https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js'></script>
<script src='<?= base_url('assets/ledger-import.js?v=20260914-report-data') ?>'></script>
<script src='<?= base_url('assets/ledger-page.js?v=20260918-name-left') ?>'></script>
<script src='<?= base_url('assets/hud-chart.js?v=20260914-trends4') ?>'></script>
<script src='<?= base_url('assets/dashboard-summary.js?v=20260916-year-label') ?>'></script>
<script src='https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js'></script>
<script src='<?= base_url('assets/attendance-ui.js?v=20260919-qr-realtime') ?>'></script>
<script src='<?= base_url('assets/attendance-live.js?v=20260919') ?>'></script>
<script src='<?= base_url('assets/attendance-recap-detail.js?v=20260914-september-data') ?>'></script>
<script src='<?= base_url('assets/reports-tabs.js?v=20260914c') ?>'></script>
<script src='<?= base_url('assets/schedule-actions.js?v=20260918-observer-fix') ?>'></script>
<script src='<?= base_url('assets/maintenance-ui.js?v=20260919-fix') ?>'></script>
<script src='<?= base_url('assets/maintenance-fix.js?v=20260919c') ?>'></script>
<script src='<?= base_url('assets/maintenance-upload.js?v=20260919') ?>'></script>
<script src='<?= base_url('assets/maintenance-upload-v2.js?v=20260919-csrf2-manifest') ?>'></script>
<script src='<?= base_url('assets/maintenance-csrf-fix.js?v=20260919') ?>'></script>
<script>
(function(){
 function bindWorkspaceNavigation(){
  document.querySelectorAll('[data-page]').forEach(function(button){
   if(button.dataset.directNavigation)return;
   button.dataset.directNavigation='1';
   button.addEventListener('click',function(event){
    event.preventDefault();
    event.stopImmediatePropagation();
    if(typeof window.render!=='function'){window.alert('AIWalas belum selesai memuat. Silakan tunggu sebentar.');return}
    window.page=button.dataset.page;
    try{window.render()}catch(error){console.error(error);window.alert('Menu gagal dibuka: '+error.message)}
   },true);
  });
 }
 bindWorkspaceNavigation();
 if(window.MutationObserver)new MutationObserver(bindWorkspaceNavigation).observe(document.body,{childList:true,subtree:true});
})();
</script>
<script src='<?= base_url('assets/teacher-assessment-ui.js?v=20260920-table-save') ?>'></script>
<script src='<?= base_url('assets/teacher-assessment-save.js?v=20260920-average2') ?>'></script>
<script src='<?= base_url('assets/teacher-assessment-combined.js?v=20260920-clearable') ?>'></script>
<script src='<?= base_url('assets/teacher-journal-ui.js?v=20260920-journal-form') ?>'></script>
<script src='<?= base_url('assets/teacher-journal-five.js?v=20260920-five') ?>'></script>
</body>
</html>
